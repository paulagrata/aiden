# Getting To Know Each Other

This the is scrum team  Iteration Station main website
- get to know each teammate
- look at our marketing flyer


[Link to Getting To Know Each Other team webstie](https://witty-meadow-055b73d10.1.azurestaticapps.net/)

[Link to Aiden repo project](https://github.com/EricJPogue/Aidan)
